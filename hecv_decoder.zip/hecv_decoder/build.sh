#!/bin/bash

#make -C build/ clean
make -C build/ -j 4
