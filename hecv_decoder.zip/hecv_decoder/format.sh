#!/bin/bash

for i in `find . -name "*.cpp"`;do
	clang-format -i $i
done
for i in `find . -name "*.h"`;do
	clang-format -i $i
done

