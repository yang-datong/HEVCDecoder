#include "TAppDecTop.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
  Int returnCode = EXIT_SUCCESS;
  TAppDecTop cTAppDecTop;

  // print information
  fprintf(stdout, "\n");
  fprintf(stdout, "HM software: Decoder Version [%s] (including RExt)",
          NV_VERSION);
  fprintf(stdout, NVM_ONOS);
  fprintf(stdout, NVM_COMPILEDBY);
  fprintf(stdout, NVM_BITS);
  fprintf(stdout, "\n");

  // create application decoder class
  cTAppDecTop.create();

  // parse configuration
  if (!cTAppDecTop.parseCfg(argc, argv)) {
    cTAppDecTop.destroy();
    returnCode = EXIT_FAILURE;
    return returnCode;
  }

  // starting time
  Double dResult;
  clock_t lBefore = clock();

  // call decoding function
  cTAppDecTop.decode();

  if (cTAppDecTop.getNumberOfChecksumErrorsDetected() != 0) {
    printf("\n\n***ERROR*** A decoding mismatch occured: signalled md5sum does "
           "not match\n");
    returnCode = EXIT_FAILURE;
  }

  // ending time
  dResult = (Double)(clock() - lBefore) / CLOCKS_PER_SEC;
  printf("\n Total Time: %12.3f sec.\n", dResult);

  // destroy application decoder class
  cTAppDecTop.destroy();

  return returnCode;
}

//! \}
